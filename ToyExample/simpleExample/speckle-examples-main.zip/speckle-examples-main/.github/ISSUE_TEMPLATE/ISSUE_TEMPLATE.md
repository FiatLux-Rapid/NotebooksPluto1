---
name: New issue
about: Create a report to help us improve
title:
labels:
assignees:
---

If it's your first time here - or you forgot about them - make sure you read the [contribution guidelines](CONTRIBUTING.md), and then feel free to delete this line!

### Expected vs. Actual Behavior

Describe the problem here.

### Reproduction Steps & System Config (win, osx, web, etc.)

Let us know how we can reproduce this, and attach relevant files (if any).

### Proposed Solution (if any)

Let us know what how you would solve this.

#### Optional: Affected Projects

Does this issue propagate to other dependencies or dependents? If so, list them here!
